from .pd2ppt import df_to_powerpoint
from .pd2ppt import df_to_table
