from datetime import datetime
def calculate_age(birth_year):
    return datetime.today().year - birth_year
